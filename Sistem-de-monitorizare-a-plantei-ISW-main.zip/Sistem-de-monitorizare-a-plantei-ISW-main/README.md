# Sistem-de-monitorizare-a-plante-ISW
Tema proiectului nostru este un sistem de monitorizare a platei.
Membri proiectului sunt: Dimanescu Roxana-Georgiana (project manager), Juganaru Daniela (delevoper software), Munteanu Raluca (delevoper software) și Neamțu Elena (tester).
