package com.example.plant_monitoring_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
